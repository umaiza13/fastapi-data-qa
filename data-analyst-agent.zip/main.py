from fastapi import FastAPI, HTTPException, Request
from pydantic import BaseModel
from typing import Any
import openai
import traceback

# Sanand proxy setup
openai.api_key = "eyJhbGciOiJIUzI1NiJ9.eyJlbWFpbCI6IjIzZjIwMDI5NzhAZHMuc3R1ZHkuaWl0bS5hYy5pbiJ9.ahEQqUPp0yOwhjVUchlclw2tIkZNyhVmeZ7P3GyhYcQ"  # use your actual key
openai.api_base = "https://aiproxy.sanand.workers.dev/openai/v1"

app = FastAPI()

# Define the input model

class TaskInput(BaseModel):
    task: str

# Ask GPT for an answer
def ask_gpt(task: str) -> str:
    try:
        response = openai.ChatCompletion.create(
            model="gpt-4o-mini",
            messages=[
                {
                    "role": "system",
                    "content": (
                        "You are a data analyst who answers data questions and "
                        "returns only the final output as a JSON array. "
                        "Do not include code or explanation — only JSON."
                        "as raw JSON — no code block, no explanation, no ```json wrapping."
                    )
                },
                {"role": "user", "content": task}
            ]
        )
        return response.choices[0].message["content"]
    except Exception as e:
        return f"Error contacting GPT: {str(e)}"


# Evaluate generated code (optional, dangerous — sandbox if possible)
def run_python_code(code: str) -> Any:
    try:
        local_vars = {}
        exec(code, {}, local_vars)
        return local_vars.get("result", "No `result` variable found.")
    except Exception as e:
        return f"Error running code: {str(e)}\n{traceback.format_exc()}"

@app.post("/api/")
async def process_task(input_data: TaskInput):
    gpt_response = ask_gpt(input_data.task)

    # If GPT gives a code block, try executing it (optional)
    if "```python" in gpt_response:
        try:
            code = gpt_response.split("```python")[1].split("```")[0]
            execution_result = run_python_code(code)
            return {"gpt_response": gpt_response, "code_result": execution_result}
        except Exception as e:
            return {"gpt_response": gpt_response, "error": str(e)}
    else:
        return {"gpt_response": gpt_response}
